export default function Loader() {
  return (
    <div className="loader-overlay">
      <span className="loader"></span>
    </div>
  );
}
